package com.claimswift.model;

import jakarta.persistence.*;

@Entity
@Table(name = "claim_parts")
public class ClaimPart {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "claim_id", nullable = false)
    private Claim claim;
    
    @Column(name = "part_name", nullable = false)
    private String partName;
    
    @Column(nullable = false)
    private Double amount;
    
    // Constructors
    public ClaimPart() {}
    
    public ClaimPart(String partName, Double amount) {
        this.partName = partName;
        this.amount = amount;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public Claim getClaim() {
        return claim;
    }
    
    public void setClaim(Claim claim) {
        this.claim = claim;
    }
    
    public String getPartName() {
        return partName;
    }
    
    public void setPartName(String partName) {
        this.partName = partName;
    }
    
    public Double getAmount() {
        return amount;
    }
    
    public void setAmount(Double amount) {
        this.amount = amount;
    }
}