package com.claimswift.service;

import com.claimswift.model.Claim;
import com.claimswift.model.ClaimPart;
import com.claimswift.model.ClaimStatus;
import com.claimswift.model.User;
import com.claimswift.repository.ClaimRepository;
import com.claimswift.repository.ClaimPartRepository;
import com.claimswift.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ClaimService {

    @Autowired
    private ClaimRepository claimRepository;

    @Autowired
    private ClaimPartRepository claimPartRepository;

    @Autowired
    private UserRepository userRepository;

    public Claim createClaim(Long userId, String imagePath, String pdfPath) {
        return userRepository.findById(userId).map(user -> {
            Claim claim = new Claim();
            claim.setUser(user);
            claim.setImagePath(imagePath);
            claim.setPdfPath(pdfPath);
            claim.setStatus(ClaimStatus.PENDING);
            return claimRepository.save(claim);
        }).orElse(null);
    }

    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }

    public List<Claim> getClaimsByUserId(Long userId) {
        return claimRepository.findByUserId(userId);
    }

    public Claim getClaimById(Long id) {
        return claimRepository.findById(id).orElse(null);
    }

    @Transactional
    public Claim approveClaim(Long claimId, List<ClaimPart> parts) {
        Optional<Claim> claimOpt = claimRepository.findById(claimId);
        if (claimOpt.isEmpty()) return null;

        Claim claim = claimOpt.get();

        // Clear existing parts (required for orphan removal)
        claim.getClaimParts().clear();

        double total = 0.0;

        for (ClaimPart part : parts) {
            part.setClaim(claim);
            claim.getClaimParts().add(part);
            total += part.getAmount();
        }

        claim.setTotalEstimation(total);
        claim.setStatus(ClaimStatus.APPROVED);
        claim.setUpdatedAt(LocalDateTime.now());

        return claimRepository.save(claim);
    }

    @Transactional
    public Claim disapproveClaim(Long claimId) {
        Optional<Claim> claimOpt = claimRepository.findById(claimId);
        if (claimOpt.isPresent()) {
            Claim claim = claimOpt.get();
            claim.setStatus(ClaimStatus.DISAPPROVED);
            claim.setUpdatedAt(LocalDateTime.now());
            return claimRepository.save(claim);
        }
        return null;
    }

    public List<ClaimPart> getClaimParts(Long claimId) {
        return claimPartRepository.findByClaimId(claimId);
    }
}
