package com.claimswift.service;

import com.claimswift.model.Role;
import com.claimswift.model.User;
import com.claimswift.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class AuthService {
    
    @Autowired
    private UserRepository userRepository;
    
    public User login(String email, String password, String roleStr) {
        Optional<User> userOpt = userRepository.findByEmailAndPassword(email, password);
        
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            Role requestedRole = Role.valueOf(roleStr.toUpperCase());
            
            if (user.getRole().equals(requestedRole)) {
                return user;
            }
        }
        return null;
    }
    
    public User register(User user) {
        if (userRepository.existsByEmail(user.getEmail())) {
            return null;
        }
        return userRepository.save(user);
    }
}