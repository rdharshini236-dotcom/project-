package com.claimswift.controller;

import com.claimswift.dto.ClaimPartDTO;
import com.claimswift.model.Claim;
import com.claimswift.model.ClaimPart;
import com.claimswift.service.ClaimService;
import com.claimswift.service.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/claims")
@CrossOrigin(origins = "*")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    @Autowired
    private FileStorageService fileStorageService;

    // -------------------- CREATE CLAIM --------------------
    @PostMapping("/create")
    public ResponseEntity<?> createClaim(
            @RequestParam("userId") Long userId,
            @RequestParam("image") MultipartFile image,
            @RequestParam(value = "pdf", required = false) MultipartFile pdf) {

        try {
            String imagePath = fileStorageService.storeFile(image);
            String pdfPath = (pdf != null && !pdf.isEmpty()) ? fileStorageService.storeFile(pdf) : null;

            Claim claim = claimService.createClaim(userId, imagePath, pdfPath);

            Map<String, Object> response = new HashMap<>();
            response.put("message", "Claim created successfully");
            response.put("claim", claim);

            return ResponseEntity.status(HttpStatus.CREATED).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to create claim", "details", e.getMessage()));
        }
    }

    // -------------------- GET ALL CLAIMS --------------------
    @GetMapping("/all")
    public ResponseEntity<?> getAllClaims() {
        return ResponseEntity.ok(claimService.getAllClaims());
    }

    // -------------------- GET CLAIMS BY USER --------------------
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getClaimsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(claimService.getClaimsByUserId(userId));
    }

    // -------------------- GET CLAIM BY ID --------------------
    @GetMapping("/{id}")
    public ResponseEntity<?> getClaimById(@PathVariable Long id) {
        Claim claim = claimService.getClaimById(id);
        return (claim != null) ? ResponseEntity.ok(claim) : ResponseEntity.notFound().build();
    }

    // -------------------- APPROVE CLAIM --------------------
    @PostMapping("/{id}/approve")
    public ResponseEntity<?> approveClaim(
            @PathVariable Long id,
            @RequestBody List<ClaimPartDTO> partDTOs) {

        List<ClaimPart> claimParts = partDTOs.stream()
                .map(dto -> new ClaimPart(dto.getPartName(), dto.getAmount()))
                .collect(Collectors.toList());

        Claim updatedClaim = claimService.approveClaim(id, claimParts);

        if (updatedClaim == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Claim not found"));
        }

        return ResponseEntity.ok(Map.of(
                "message", "Claim approved successfully",
                "claim", updatedClaim
        ));
    }

    // -------------------- DISAPPROVE CLAIM --------------------
    @PostMapping("/{id}/disapprove")
    public ResponseEntity<?> disapproveClaim(@PathVariable Long id) {
        Claim claim = claimService.disapproveClaim(id);

        if (claim == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Claim not found"));
        }

        return ResponseEntity.ok(Map.of(
                "message", "Claim disapproved successfully",
                "claim", claim
        ));
    }
}
