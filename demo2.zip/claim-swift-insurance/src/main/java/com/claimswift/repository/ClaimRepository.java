package com.claimswift.repository;

import com.claimswift.model.Claim;
import com.claimswift.model.ClaimStatus;
import com.claimswift.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Long> {
    List<Claim> findByUser(User user);
    List<Claim> findByStatus(ClaimStatus status);
    List<Claim> findByUserId(Long userId);
}