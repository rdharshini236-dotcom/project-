package com.claimswift.repository;

import com.claimswift.model.ClaimPart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ClaimPartRepository extends JpaRepository<ClaimPart, Long> {
    List<ClaimPart> findByClaimId(Long claimId);
}